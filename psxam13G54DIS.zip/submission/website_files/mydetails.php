<?php
	include "session.php";
	include "connection.php";
	$select = "SELECT * FROM Students WHERE student_id = '".$_SESSION['name']."';";
	$return = mysqli_query($connection, $select);
	$data = mysqli_fetch_array($return);
	$selectcourse = "SELECT course_title FROM Courses WHERE course_id = '".$data[6]."';";
	$returncourse = mysqli_query($connection, $selectcourse);
	$datacourse = mysqli_fetch_array($returncourse);
	
	if(!empty($_POST['updateemail'])){
		$email = mysqli_real_escape_string($connection, $_POST['updateemail']);
		$emailupdate = "UPDATE Students SET email ='".$email."' WHERE student_id = '".$_SESSION['name']."';";
		mysqli_query($connection, $emailupdate);
		header("Location: /~psxam13/mydetails.php");
	}

	if(!empty($_POST['updatephone'])){
		$phone = mysqli_real_escape_string($connection, $_POST['updatephone']);
		$phoneupdate = "UPDATE Students SET phone_num ='".$phone."' WHERE student_id = '".$_SESSION['name']."';";
		mysqli_query($connection, $phoneupdate);
		header("Location: /~psxam13/mydetails.php");
	}
	
	if(!empty($_POST['updateaddress'])){
		$address = mysqli_real_escape_string($connection, $_POST['updateaddress']);
		$addressupdate = "UPDATE Students SET address ='".$address."' WHERE student_id = '".$_SESSION['name']."';";
		mysqli_query($connection, $addressupdate);
		header("Location: /~psxam13/mydetails.php");
	}



	
	
?>
<html>
<head>
	<title>My Details</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<form action="login.php" method="POST"><input class="logout" type="submit" name="logoutbutton" value="Log Out" onclick="return confirm('Are you sure you want to log out?')"></form>
<form action="/~psxam13"><input class="home" type="submit" value="Home"></form>	
	<h1>My Details</h1>

	<div class="flex-container">
		<div class="detailsbox">
			<?php
			if(!isset($_POST['updatebutton'])) {
			?>
			<table class="detailstable">
				<tr>
					<td class="detailstd">Student ID:</td><td class="detailstd"><?php echo $data[0]; ?></td>
				</tr>
				<tr>
					<td class="detailstd">Name:</td><td class="detailstd"><?php echo $data[1], " ", $data[2]; ?></td>
				</tr>
				<tr>
					<td class="detailstd">Email:</td><td class="detailstd"><?php echo $data[3]; ?></td>
				</tr>
				<tr>
					<td class="detailstd">Phone:</td><td class="detailstd"><?php echo $data[4]; ?></td>
				</tr>
				<tr>
					<td class="detailstd">Address:</td><td class="detailstd"><?php echo $data[5]; ?></td>
				</tr>
				<tr>
					<td class="detailstd">Course:</td><td class="detailstd"><?php echo $datacourse[0]; ?></td>
				</tr>
					<td class="detailstd"></td><td class="detailstd"><form action="mydetails.php" method="POST"><input class="button" type="submit" name="updatebutton" value="Update Details"></form>

				<tr>
					
			</table>
			<?php
			} else {
			?>
			<table class="detailstable">
				<form action="mydetails.php" method="POST">
				<tr>
					<td class="detailstd">Student ID:</td><td class="detailstd"><?php echo $data[0]; ?></td>
				</tr>
				<tr>
					<td class="detailstd">Name:</td><td class="detailstd"><?php echo $data[1], " ", $data[2]; ?></td>
				</tr>
				<tr>
					<td class="detailstd">Email:</td><td class="detailstd"><input name="updateemail" type="text" placeholder="leave blank if not updating"/></td>
				</tr>
				<tr>
					<td class="detailstd">Phone:</td><td class="detailstd"><input name="updatephone" type="text" placeholder="leave blank if not updating"/></td>
				</tr>
				<tr>
					<td class="detailstd">Address:</td><td class="detailstd"><input name="updateaddress" type="text" placeholder="leave blank if not updating"/></td>
				</tr>
				<tr>
					<td class="detailstd">Course:</td><td class="detailstd"><?php echo $datacourse[0]; ?></td>
				</tr>
					<td class="detailstd"></td><td class="detailstd"><input class="button" type="submit" name="updatesubmit" value="Update" onclick="return confirm('Are you sure you want to update these details?')"></form>

				<tr>
				</form>	
			</table>
			<?php
			}
			?>
			
		</div>
	</div>
</body>
</html>