<?php
	session_start();
	include "connection.php";
	if(isset($_POST['logoutbutton'])){
		session_destroy();
		mysql_close($connection);
	}

	if(!isset($_SESSION['name'])) {	
		$studentid = mysqli_real_escape_string($connection, $_POST['studentid']);
		$password = mysqli_real_escape_string($connection, $_POST['password']);
		$select = "SELECT * FROM Students WHERE student_id = '".$studentid."' AND password = AES_ENCRYPT('".$password."', 'secret');";
		$return = mysqli_query($connection, $select);
		$data = mysqli_fetch_array($return);
	
		if($data[0] > 0) {
			$_SESSION['name'] = $studentid;
			header("Location: /~psxam13");
		}
				
	} else {
		header("Location: /~psxam13");	
	}
	
	
?>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Log in</title>
</head>
<body>

  <div class="center">

<div class="flex-container">
  <div class="box">
<h2>Log in</h2>
    <table>
<form class="login" action="login.php" method="POST">  
	<tr> 
      <td><label for="studentid"> Student ID </label></td>
      <td><input id="studentid" name="studentid" placeholder=" Student ID" required/></td>
	</tr>
	<tr> 
      <td><label for="password"> Your password </label></td>
      <td><input id="password" name="password" type="password" placeholder=" Password" required/></td> 
	</tr>			
	<tr> 
      <td><input class="button" type="submit" name="login" value = 'Log in'required/></td> 
  </tr>			
</form>
    </table>
  </div>
  <div class="box">
<h2>Register</h2>
    <table>
<form class="addstudent" action="addnewstudent.php" method="POST"> 			
	<tr> 
      <td><label for="firstnamesignup">First Name</label></td>
      <td><input id="firstnamesignup" name="firstnamesignup" type="text" required/></td>
	</tr>
	<tr> 
      <td><label for="lastnamesignup"> Last Name</label></td>
      <td><input id="lastnamesignup" name="lastnamesignup" type="text" required/></td> 
	</tr>
	<tr> 
      <td><label for="emailsignup"> Email</label></td>
      <td><input id="emailsignup" name="emailsignup" type="text" required/></td> 
	</tr>
	<tr> 
      <td><label for="phonesignup"> Phone Number</label></td>
      <td><input id="phonesignup" name="phonesignup" type="tel" required/></td> 
	</tr>
	<tr> 
      <td><label for="addresssignup"> Address</label></td>
      <td><input id="addresssignup" name="addresssignup" type="text" required/></td> 
	</tr>
	<tr>
      <td><label for="course"> Course</label></td>
		<td><select id="course" name = "coursesignup" required>
			<option disabled selected value></option>
			<option value="1">History BA</option>
			<option value="2">Geography BA</option>
			<option value="3">English Language BA</option>
			<option value="4">English Literature BA</option>
			<option value="5">Politics BSc</option>
			<option value="6">Philosophy BA</option>
			<option value="7">Chemistry BSc</option>
			<option value="8">Physics BSc</option>
			<option value="9">Mathematics BSc</option>
			<option value="10">Economics BSc</option>
			<option value="11">History MA</option>
			<option value="12">Geography MA</option>
			<option value="13">English Language MA</option>
			<option value="14">English Literature MA</option>
			<option value="15">Politics MSc</option>
			<option value="16">Philosophy MA</option>
			<option value="17">Chemistry MSc</option>
			<option value="18">Physics MSc</option>
			<option value="19">Mathematics MSc</option>
			<option value="20">Economics MSc</option>								
          </select></td>
	</tr>
	<tr> 
      <td><label for="passwordsignup">Password </label></td>
      <td><input id="passwordsignup" name="passwordsignup" type="password" required/></td>
	</tr>
	<tr>
      <td><input class="button" type="submit" name="submitsignup" value="Register"required/></td> 
	</tr>				
</form>
    </table>
  </div>
</div>
<p class="regmessage1"><?php if($_SESSION['newuseradded'] == "Success"){ echo "Registration successful - Student ID: ", $_SESSION['newuserid']; $_SESSION['newuseradded'] = "";} ?></p>
<p class="regmessage2"><?php if($_SESSION['newuseradded'] == "Failure"){ echo "Registration unsuccessful - email already assigned to existing user"; $_SESSION['newuseradded'] = "";} ?></p>
<p class="regmessage1">If log in attempt fails, Student ID and Password do not match<p>  
</div>
</body>
</html>	

