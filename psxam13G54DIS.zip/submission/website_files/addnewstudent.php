<?php
	session_start();
	include "connection.php";
	
	$first = mysqli_real_escape_string($connection, $_POST['firstnamesignup']);
	$last = mysqli_real_escape_string($connection, $_POST ['lastnamesignup']);
	$email = mysqli_real_escape_string($connection, $_POST['emailsignup']);
	$phone = mysqli_real_escape_string($connection, $_POST['phonesignup']);
	$address = mysqli_real_escape_string($connection, $_POST['addresssignup']);
	$course = mysqli_real_escape_string($connection, $_POST['coursesignup']);
	$password = mysqli_real_escape_string($connection, $_POST['passwordsignup']);
	$submit = mysqli_real_escape_string($connection, $_POST['submitsignup']);

	$select = "SELECT * FROM Students WHERE email = '".$email."';";
	$return = mysqli_query($connection, $select);
	$data = mysqli_fetch_array($return);

	if(mysqli_num_rows($return) > 0) {
		header("Location: /~psxam13/login.php");
		$_SESSION['newuseradded'] = "Failure";
	} else {
		$sql = "INSERT INTO Students (student_id, first_name, last_name, email, phone_num, address, course_id, password) SELECT 0, '$first', '$last', '$email', '$phone', '$address', '$course', AES_ENCRYPT('$password', 'secret');";
		$result = mysqli_query($connection, $sql);
		$sqlnewuserid = "SELECT student_id FROM Students WHERE email = '".$email."';";
		$newuseridresult = mysqli_query($connection, $sqlnewuserid);
		$newuseridarray = mysqli_fetch_array($newuseridresult);
		$_SESSION['newuserid'] = $newuseridarray['student_id'];
		$_SESSION['newuseradded'] = "Success";
		header("Location: /~psxam13/login.php");
	}			
?>
