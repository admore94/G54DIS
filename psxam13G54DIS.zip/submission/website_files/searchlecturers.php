<?php
	include "session.php";
	include "connection.php";

	if(!empty($_POST['searchlecturername'])){
		$lecturer = mysqli_real_escape_string($connection, $_POST['searchlecturername']);
		$selectlecturer = "SELECT * FROM Lecturers WHERE last_name = '".$lecturer."';";
		$returnlecturer = mysqli_query($connection, $selectlecturer);
		$lecturerdata = mysqli_fetch_array($returnlecturer);
	}

	if(!empty($_POST['searchlecturermodule'])){
		$lecturermodulename = mysqli_real_escape_string($connection, $_POST['searchlecturermodule']);
		$selectlecturerid = "SELECT module_leader FROM Modules WHERE module_name = '".$lecturermodulename."';";
		$returnlecturerid = mysqli_query($connection, $selectlecturerid);
		$lectureriddata = mysqli_fetch_array($returnlecturerid);
		$selectlecturername = "SELECT * FROM Lecturers WHERE lecturer_id = '".$lectureriddata['module_leader']."';";
		$returnlecturer = mysqli_query($connection, $selectlecturername);
		$lecturernamedata = mysqli_fetch_array($returnlecturer);
	}		


?>
<html>
<head>
	<title>Search Lecturers</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<form action="login.php" method="POST"><input class="logout" type="submit" name="logoutbutton" value="Log Out" onclick="return confirm('Are you sure you want to log out?')"></form>
<form action="/~psxam13"><input class="home" type="submit" value="Home"></form>
<form action="modules.php"><input class="back" type="submit" value="Back"></form>
	<h1>Search Lecturers</h1>
	<div class="flex-container">
	<form action="searchlecturers.php" method="POST">
		<label class="regmessage1" for="searchlecturername"> Search by Lecturer Last Name</label>
		<input id="searchlecturername" name="searchlecturername" placeholder="Lecturer Name" required/>
		<input class="button" type="submit" value="Search"/>
	</form>
	<form action="searchlecturers.php" method="POST">
		<label class="regmessage1" for="searchlecturermodule"> Search by Module Name</label>
		<input id="searchlecturermodule" name="searchlecturermodule" placeholder="Module Name" required/>
		<input class="button" type="submit" value="Search"/>
	</form>
	<?php
		if(!empty($lecturer)){
	?>
			<table class="lecturertable">
				<tr>
					<th class="lecturertd">Name</th>
					<th class="lecturertd">Phone</th>
					<th class="lecturertd">Room</th>
				</tr>
				<tr>
					<td class="lecturertd"><?php if(!empty($lecturerdata['last_name'])) {echo $lecturerdata['first_name'], " ", $lecturerdata['last_name'];} else {echo "N/A";} ?></td>
					<td class="lecturertd"><?php if(!empty($lecturerdata['phone_num'])) {echo $lecturerdata['phone_num'];} else {echo "N/A";} ?></td>
					<td class="lecturertd"><?php if(!empty($lecturerdata['room'])) {echo $lecturerdata['room'];} else {echo "N/A";} ?></td>

				</tr>
			</table>
	<?php
		} 
	?>
	<?php
		if(!empty($lecturermodulename)){
	?>
			<table class="lecturertable">
				<tr>
					<th class="lecturertd">Module Leader Name</th>
					<th class="lecturertd">Phone</th>
					<th class="lecturertd">Room</th>
				</tr>
				<tr>
					<td class="lecturertd"><?php if(!empty($lecturernamedata['last_name'])) {echo $lecturernamedata['first_name'], " ", $lecturernamedata['last_name'];} else {echo "N/A";} ?></td>
					<td class="lecturertd"><?php if(!empty($lecturernamedata['phone_num'])) {echo $lecturernamedata['phone_num'];} else {echo "N/A";} ?></td>
					<td class="lecturertd"><?php if(!empty($lecturernamedata['room'])) {echo $lecturernamedata['room'];} else {echo "N/A";} ?></td>
				</tr>
			</table>
	<?php
		} 
	?>


	</div>
</body>
</html