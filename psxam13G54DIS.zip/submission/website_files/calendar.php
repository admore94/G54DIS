<?php
	include "session.php";
	include "connection.php";
	$select = "SELECT * FROM Student_Exam_Admission WHERE student_id = '".$_SESSION['name']."';";
	$return = mysqli_query($connection, $select);	
?>

<html>
<head>
	<title>My Calendar</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<form action="login.php" method="POST"><input class="logout" type="submit" name="logoutbutton" value="Log Out" onclick="return confirm('Are you sure you want to log out?')"></form>
<form action="/~psxam13"><input class="home" type="submit" value="Home"></form>

	<h1>My Calendar</h1>
	<div class="flex-container">
		<div>
			<table class="calendartable">
				<tr>
					<th>Exam ID</th>
					<th>Date & Time</th>
					<th>Module</th>
					<th>Address</th>
				</tr>
				<?php
					
					while($row = mysqli_fetch_array($return)) {
						$selectexam = "SELECT * FROM Exams WHERE exam_id = '".$row['exam_id']."';";
						$returnexam = mysqli_query($connection, $selectexam); 
						$rowexam = mysqli_fetch_array($returnexam);
						
				?>
					<tr>
						<td><?php echo $rowexam['exam_id']; ?></td>
						<td><?php echo $rowexam['date_and_time']; ?></td>
						<?php
							$selectmodule = "SELECT module_name FROM Modules WHERE module_id = '".$rowexam['module_id']."';";
							$returnmodule = mysqli_query($connection, $selectmodule);
							$rowmodule = mysqli_fetch_array($returnmodule);
						?>
						<td><?php echo $rowmodule['module_name']; ?></td>
						<td><?php echo $rowexam['address']; ?></td>
					</tr>
				<?php
					}
				?>
			</table>
		</div>
	</div>
</body>
</html>