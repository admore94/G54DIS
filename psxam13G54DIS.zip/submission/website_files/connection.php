<?php

$config = parse_ini_file('/lhome/psxam13/config.ini');
$connection = mysqli_connect($config["servername"],$config["username"],$config["password"],$config["databasename"]);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

mysqli_select_db($connection_mysql,"psxam13_G54DIS");




?>
