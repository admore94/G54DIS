<?php
	include "session.php";
	include "connection.php";
	
	$work = "N/A";

	if(!empty($_POST['searchmodule'])){
		$module = mysqli_real_escape_string($connection, $_POST['searchmodule']);
		$selectmodule = "SELECT * FROM Modules WHERE module_name = '".$module."';";
		$returnmodule = mysqli_query($connection, $selectmodule);
		$moduledata = mysqli_fetch_array($returnmodule);
	}
	
	if(isset($_POST['modulebutton'])) {
		$insert = "INSERT INTO Student_Module_Enrollment VALUES (0, '".$_SESSION['name']."', '".$_SESSION['module']."');";
		mysqli_query($connection, $insert);
		$examselect = "SELECT * from Exams WHERE module_id = '".$_SESSION['module']."';";
		$returnexam = mysqli_query($connection, $examselect);
		$examdata = mysqli_fetch_array($returnexam);
		$insertexam = "INSERT INTO Student_Exam_Admission VALUES (0, '".$examdata['exam_id']."', '".$_SESSION['name']."');";
		mysqli_query($connection, $insertexam); 
		$_SESSION['module'] = "";
	}

	if(!empty($_POST['searchcourse'])){
		$course = mysqli_real_escape_string($connection, $_POST['searchcourse']);
		$selectcourse = "SELECT course_id FROM Courses WHERE course_title = '".$course."';";
		$returncourse = mysqli_query($connection, $selectcourse);
		$coursedata = mysqli_fetch_array($returncourse);
		$modulesdata = "SELECT * FROM Modules WHERE course_id = '".$coursedata['course_id']."';";
		$returnmodules = mysqli_query($connection, $modulesdata);
	}
?>

<html>
<head>
	<title>Search Modules</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<form action="login.php" method="POST"><input class="logout" type="submit" name="logoutbutton" value="Log Out" onclick="return confirm('Are you sure you want to log out?')"></form>
<form action="/~psxam13"><input class="home" type="submit" value="Home"></form>
<form action="modules.php"><input class="back" type="submit" value="Back"></form>

	<h1>Search Modules</h1>
	<div class="flex-container">
	<form action="searchmodules.php" method="POST">
		<label class="regmessage1" for="searchmodule"> Search and Add Modules by Module Name</label>
		<input id="searchmodule" name="searchmodule" placeholder="Module Name" required/>
		<input class="button" type="submit" value="Search"/>
	</form>
	<form action="searchmodules.php" method="POST">
		<label class="regmessage1" for="searchcourse"> Search Modules by Course Name</label>
		<input id="searchcourse" name="searchcourse" placeholder="Course Name" required/>
		<input class="button" type="submit" value="Search"/>
	</form>
	<?php
		if(!empty($module)){
	?>
			<table class="mymodulestable">
				<tr>
					<th>Name</th>
					<th>Semester</th>
					<th>Credits</th>
					<th>Module Leader</th>
					<th>Add Module</th>
				</tr>
				<tr>
					<td><?php if(!empty($moduledata['module_name'])) {$_SESSION['module']=$moduledata['module_id']; echo $moduledata['module_name'];} else {echo "N/A";} ?></td>
					<td><?php if(!empty($moduledata['semester'])) { echo $moduledata['semester'];} else {echo "N/A";} ?></td>
					<td><?php if(!empty($moduledata['credits'])) { echo $moduledata['credits'];} else {echo "N/A";}  ?></td>
					<?php
						$selectmoduleleader = "SELECT * FROM Lecturers WHERE lecturer_id = '".$moduledata['module_leader']."';";
						$returnmoduleleader = mysqli_query($connection, $selectmoduleleader);
						$moduleleader = mysqli_fetch_array($returnmoduleleader);
					?>
					<td><?php if(!empty($moduleleader['first_name'])) { echo $moduleleader['first_name'], " ", $moduleleader['last_name'];} else {echo "N/A";} ?></td>
					<td><?php if(!empty($moduledata['module_name'])) {?><form action="searchmodules.php" method="POST"><input class="button" type="submit" name="modulebutton" value="Add Module"></form> <?php } else { echo "N/A";} ?></td>
				</tr>
			</table>
	<?php
		} 
	?>
	<?php
		if(!empty($course)) {
	?>
			<table class="mymodulestable">
				<tr>
					<th>Name</th>
					<th>Semester</th>
					<th>Credits</th>
					<th>Module Leader</th>
				</tr>
				<?php
				if(mysqli_num_rows($returnmodules) > 0){
					
					while($row = mysqli_fetch_array($returnmodules)) {                            
				?>
					<tr>
						<td><?php echo $row['module_name']; ?></td>
						<td><?php echo $row['semester']; ?></td>
						<td><?php echo $row['credits']; ?></td>
						<?php
							$selectmoduleleader = "SELECT * FROM Lecturers WHERE lecturer_id = '".$row['module_leader']."';";
							$returnmoduleleader = mysqli_query($connection, $selectmoduleleader);
							$rowleader = mysqli_fetch_array($returnmoduleleader);
						?>
						<td><?php echo $rowleader['first_name'], " ", $rowleader['last_name']; ?></td>
					</tr>
					<?php
						}
					?>
			</table>
			<?php
				
			} else {
			?>	
					<tr>
						<td>N/A</td>
						<td>N/A</td>
						<td>N/A</td>
						<td>N/A</td>
					</tr>
			<?php
				}
			}
			?>
	</div>					
</body>
</html>

