<?php
	session_start();
	if(!isset($_SESSION['name'])) {
		header("Location: /~psxam13/login.php");
	}
?>