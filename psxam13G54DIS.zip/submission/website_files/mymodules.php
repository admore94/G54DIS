<?php
	include "session.php";
	include "connection.php";
	$select = "SELECT * FROM Student_Module_Enrollment WHERE student_id = '".$_SESSION['name']."';";
	$return = mysqli_query($connection, $select);	
?>
<html>
<head>
	<title>My Modules</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<form action="login.php" method="POST"><input class="logout" type="submit" name="logoutbutton" value="Log Out" onclick="return confirm('Are you sure you want to log out?')"></form>
<form action="/~psxam13"><input class="home" type="submit" value="Home"></form>
<form action="modules.php"><input class="back" type="submit" value="Back"></form>

	<h1>My Modules</h1>

	<div class="flex-container">
		<div>
			<table class="mymodulestable">
				<tr>
					<th class="name">Name</th>
					<th>Semester</th>
					<th>Credits</th>
					<th>Module Leader</th>
					<th>Result</th>
				</tr>
				<?php
					
					while($row = mysqli_fetch_array($return)) {
						$selectmodule = "SELECT * FROM Modules WHERE module_id = '".$row['module_id']."';";
						$returnmodule = mysqli_query($connection, $selectmodule); 
						$rowmodule = mysqli_fetch_array($returnmodule);
						
				?>
					<tr>
						
						<td class="name"><?php echo $rowmodule['module_name']; ?></td>
						<td><?php echo $rowmodule['semester']; ?></td>
						<td><?php echo $rowmodule['credits']; ?></td>
						<?php 
							$selectmoduleleader = "SELECT * FROM Lecturers WHERE lecturer_id = '".$rowmodule['module_leader']."';";
							$returnmoduleleader = mysqli_query($connection, $selectmoduleleader);
							$rowleader = mysqli_fetch_array($returnmoduleleader);
						?>
						<td><?php echo $rowleader['first_name'], " ", $rowleader['last_name'] ; ?></td>
						<?php
							$selectresult = "SELECT * FROM Results WHERE student_id = '".$_SESSION['name']."' AND module_id = '".$row['module_id']."';";
							$returnresult = mysqli_query($connection, $selectresult);
							$rowresult = mysqli_fetch_array($returnresult);
						?>
						<td><?php echo $rowresult['grade']; ?></td>
					</tr>	
				<?php
					}
				?>	
					<tr>
						<td class="name"></td>
						<td></td>
						<td></td>
						<td></td>
						<td><form action="calendar.php"><input class="button" type="submit" value="My Exams"></form></td>
					</tr>
									
			</table>
		</div>
	</div>
<form action="searchmodules.php"><input class="button" type="submit" value="Search and Add Modules"></form>
</body>
</html>