<?php
	include "session.php";
	include "connection.php";
?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Modules</title>
</head>
<body>
<form action="login.php" method="POST"><input class="logout" type="submit" name="logoutbutton" value="Log Out" onclick="return confirm('Are you sure you want to log out?')"></form>
<form action="/~psxam13"><input class="home" type="submit" value="Home"></form>
	<h1>Modules</h1>

		<div class="flex-container">
			<div class="homebox">
				<a class="homeoption" href='/~psxam13/mymodules.php' class="button">My Modules</a>
			</div>
			<div class="homebox">
				<a class="homeoption" href='/~psxam13/searchmodules.php' class="button">Search Modules</a>
			</div>
			<div class="homebox">
				<a class="homeoption" href='/~psxam13/searchlecturers.php' class="button">Search Lecturers</a>
			</div>
		</div>
			
</body>
</html>
