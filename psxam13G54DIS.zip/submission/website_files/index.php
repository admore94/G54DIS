<?php
	include "session.php";
	include "connection.php";
	

	
?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Home</title>
</head>
<body>
<form action="login.php" method="POST"><input class="logout" type="submit" name="logoutbutton" value="Log Out" onclick="return confirm('Are you sure you want to log out?')"></form>
	<h1>Home</h1>
		<div class="flex-container">
			<div class="homebox">
				<a class="homeoption" href='/~psxam13/mydetails.php'>My Details</a>
			</div>
			<div class="homebox">
				<a class="homeoption" href='/~psxam13/modules.php'>Modules</a>
			</div>
			<div class="homebox">
				<a class="homeoption" href='/~psxam13/calendar.php'>My Calendar</a>
			</div>
		</div>
			
</body>
</html>